import React from 'react';
import './globals.css';

export const metadata = {
  title: 'Mortgage Income Calculator | MLO Qualifier Pro',
  description: 'Calculate, analyze, and qualify borrower income for mortgage underwriting.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-slate-50 antialiased">{children}</body>
    </html>
  );
}