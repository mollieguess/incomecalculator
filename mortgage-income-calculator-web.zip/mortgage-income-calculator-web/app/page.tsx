'use client';

import React, { useState } from 'react';
import { IncomeType } from '../src/types/income';
import { Header } from '../src/components/Header';
import { SalaryCalculator } from '../src/components/SalaryCalculator';
import { HourlyCalculator } from '../src/components/HourlyCalculator';
import { VariableHoursCalculator } from '../src/components/VariableHoursCalculator';
import { HistoricalCalculator } from '../src/components/HistoricalCalculator';
import { YtdAnalysisCalculator } from '../src/components/YtdAnalysisCalculator';

const OPTIONS: { type: IncomeType; title: string; description: string }[] = [
  { type: 'SALARY', title: 'Salary Income', description: 'Fixed annual or monthly guaranteed compensation.' },
  { type: 'HOURLY', title: 'Hourly Income', description: 'Standard hourly base rate calculations (FNMA 52-wk rule).' },
  { type: 'VARIABLE_HOURS', title: 'Variable Hours', description: 'Fluctuating hourly work schedules with historical averaging.' },
  { type: 'OVERTIME', title: 'Overtime', description: 'Supplemental overtime income with 2-year history analysis.' },
  { type: 'BONUS', title: 'Bonus', description: 'Variable bonus income verification & trend calculation.' },
  { type: 'COMMISSION', title: 'Commission', description: 'Commission income analysis with decline safeguards.' },
  { type: 'YTD_ANALYSIS', title: 'YTD Income Analysis', description: 'Comprehensive multi-year income trend & stability analysis.' },
];

export default function Home() {
  const [currentScreen, setCurrentScreen] = useState<IncomeType | 'HOME'>('HOME');

  const renderCalculator = () => {
    switch (currentScreen) {
      case 'SALARY':
        return <SalaryCalculator onBack={() => setCurrentScreen('HOME')} />;
      case 'HOURLY':
        return <HourlyCalculator onBack={() => setCurrentScreen('HOME')} />;
      case 'VARIABLE_HOURS':
        return <VariableHoursCalculator onBack={() => setCurrentScreen('HOME')} />;
      case 'OVERTIME':
      case 'BONUS':
      case 'COMMISSION':
        return <HistoricalCalculator type={currentScreen} onBack={() => setCurrentScreen('HOME')} />;
      case 'YTD_ANALYSIS':
        return <YtdAnalysisCalculator onBack={() => setCurrentScreen('HOME')} />;
      default:
        return (
          <div>
            <h2 className="text-[10px] font-extrabold text-slate-400 tracking-wider uppercase mb-4">
              SELECT QUALIFYING INCOME TYPE
            </h2>
            <div className="space-y-3">
              {OPTIONS.map((option) => (
                <button
                  key={option.type}
                  onClick={() => setCurrentScreen(option.type)}
                  className="w-full text-left bg-white p-4 rounded-xl border border-slate-200 hover:border-tealBrand-500 hover:shadow-md transition-all group"
                >
                  <h3 className="text-sm font-bold text-slate-900 group-hover:text-tealBrand-600">
                    {option.title}
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">{option.description}</p>
                </button>
              ))}
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 max-w-xl w-full mx-auto p-4 sm:p-6">
        {renderCalculator()}
      </main>
    </div>
  );
}