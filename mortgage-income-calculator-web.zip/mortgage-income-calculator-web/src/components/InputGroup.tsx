import React from 'react';

interface Props {
  label: string;
  value: string;
  onChangeText: (text: string) => void;
  placeholder?: string;
  prefix?: string;
  suffix?: string;
  type?: 'text' | 'date';
  helpText?: string;
}

export const InputGroup: React.FC<Props> = ({
  label,
  value,
  onChangeText,
  placeholder = '0.00',
  prefix,
  suffix,
  type = 'text',
  helpText,
}) => {
  return (
    <div className="mb-4">
      <label className="block text-xs font-semibold text-slate-800 mb-1">
        {label}
      </label>
      <div className="relative flex items-center rounded-lg border-2 border-slate-200 bg-white focus-within:border-tealBrand-600 transition-colors">
        {prefix && (
          <span className="pl-3 text-sm font-bold text-slate-400 select-none">
            {prefix}
          </span>
        )}
        <input
          type={type}
          value={value}
          onChange={(e) => onChangeText(e.target.value)}
          placeholder={placeholder}
          className="w-full py-2.5 px-3 text-sm font-semibold text-slate-900 placeholder-slate-400 focus:outline-none bg-transparent"
        />
        {suffix && (
          <span className="pr-3 text-xs font-semibold text-slate-400 select-none">
            {suffix}
          </span>
        )}
      </div>
      {helpText && <p className="text-[11px] text-slate-500 mt-1">{helpText}</p>}
    </div>
  );
};