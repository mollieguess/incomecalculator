import React from 'react';
import { CalculationResult } from '../types/income';
import { formatCurrency, formatPercentage } from '../utils/formatters';

export const HistoricalResultCard: React.FC<{ result: CalculationResult }> = ({ result }) => {
  const { trend } = result;

  return (
    <div className="mt-6 bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
      <h2 className="text-[10px] font-extrabold text-slate-400 tracking-wider uppercase">
        ESTIMATED QUALIFYING MONTHLY INCOME
      </h2>
      <div className="text-3xl sm:text-4xl font-extrabold text-tealBrand-700 my-1">
        {formatCurrency(result.monthlyQualifyingIncome)}
      </div>

      <div className="grid grid-cols-3 gap-2 bg-slate-50 rounded-xl p-3 my-4 text-center">
        <div>
          <p className="text-[10px] font-semibold text-slate-500">Current YTD</p>
          <p className="text-xs font-bold text-slate-900">{formatCurrency(result.currentYtdAverage || 0)}</p>
        </div>
        <div>
          <p className="text-[10px] font-semibold text-slate-500">Prior Year</p>
          <p className="text-xs font-bold text-slate-900">{formatCurrency(result.priorYearAverage || 0)}</p>
        </div>
        <div>
          <p className="text-[10px] font-semibold text-slate-500">Historical Avg</p>
          <p className="text-xs font-bold text-slate-900">{formatCurrency(result.historicalAverage || 0)}</p>
        </div>
      </div>

      {trend && (
        <div className="mb-4">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-extrabold text-slate-400 uppercase">TREND:</span>
            <span className={`text-xs font-bold ${trend.isDeclining ? 'text-red-600' : 'text-emerald-600'}`}>
              {trend.direction} ({formatPercentage(trend.percentageChange)})
            </span>
          </div>
          {trend.isDeclining && trend.warningMessage && (
            <div className="mt-2 bg-red-50 border border-red-200 rounded-lg p-3 text-xs font-medium text-red-700">
              ⚠️ {trend.warningMessage}
            </div>
          )}
        </div>
      )}

      <div className="pt-3 border-t border-slate-100 mb-3">
        <h3 className="text-[9px] font-extrabold text-slate-400 tracking-wider uppercase mb-1">
          CALCULATION METHODOLOGY
        </h3>
        <p className="text-xs font-medium text-slate-800 leading-snug">{result.methodology}</p>
      </div>

      <p className="text-[10px] leading-relaxed text-slate-400">
        This calculator is an educational and income-analysis tool. Results do not constitute underwriting approval. Actual qualifying income may vary based on loan program, investor, agency, lender, documentation, and underwriting requirements.
      </p>
    </div>
  );
};