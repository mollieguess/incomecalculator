import React, { useState } from 'react';
import { SalaryFrequency } from '../types/income';
import { calculateSalaryIncome } from '../calculations/salary';
import { InputGroup } from './InputGroup';
import { ResultCard } from './ResultCard';

export const SalaryCalculator: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const [frequency, setFrequency] = useState<SalaryFrequency>('ANNUAL');
  const [amount, setAmount] = useState('');

  const result = calculateSalaryIncome({ frequency, amount });

  return (
    <div>
      <div className="flex items-center mb-6">
        <button onClick={onBack} className="text-xs font-bold text-tealBrand-600 hover:text-tealBrand-700 mr-4">
          ← Back
        </button>
        <h2 className="text-lg font-extrabold text-slate-900">Salary Calculator</h2>
      </div>

      <div className="flex bg-slate-200 p-1 rounded-lg mb-4">
        <button
          className={`flex-1 py-1.5 text-xs font-bold rounded-md transition-all ${
            frequency === 'ANNUAL' ? 'bg-white text-tealBrand-700 shadow-sm' : 'text-slate-600'
          }`}
          onClick={() => setFrequency('ANNUAL')}
        >
          Annual Salary
        </button>
        <button
          className={`flex-1 py-1.5 text-xs font-bold rounded-md transition-all ${
            frequency === 'MONTHLY' ? 'bg-white text-tealBrand-700 shadow-sm' : 'text-slate-600'
          }`}
          onClick={() => setFrequency('MONTHLY')}
        >
          Monthly Salary
        </button>
      </div>

      <InputGroup
        label={frequency === 'ANNUAL' ? 'Gross Annual Salary' : 'Gross Monthly Salary'}
        value={amount}
        onChangeText={setAmount}
        prefix="$"
        placeholder={frequency === 'ANNUAL' ? '95,000.00' : '7,916.67'}
        helpText="Enter the base gross compensation prior to payroll deductions."
      />

      <ResultCard result={result} />
    </div>
  );
};