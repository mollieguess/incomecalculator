import React, { useState } from 'react';
import { calculateHistoricalIncome } from '../calculations/historicalIncome';
import { InputGroup } from './InputGroup';
import { HistoricalResultCard } from './HistoricalResultCard';

interface Props {
  type: 'OVERTIME' | 'BONUS' | 'COMMISSION';
  onBack: () => void;
}

export const HistoricalCalculator: React.FC<Props> = ({ type, onBack }) => {
  const [ytdIncome, setYtdIncome] = useState('');
  const [payPeriodDate, setPayPeriodDate] = useState('2026-06-30');
  const [priorYearIncome, setPriorYearIncome] = useState('');
  const [secondPriorYearIncome, setSecondPriorYearIncome] = useState('');

  const titleMap = {
    OVERTIME: 'Overtime Income',
    BONUS: 'Bonus Income',
    COMMISSION: 'Commission Income',
  };

  const title = titleMap[type];

  const result = calculateHistoricalIncome({
    incomeTypeLabel: title,
    ytdIncome,
    payPeriodDate,
    priorYearIncome,
    secondPriorYearIncome,
  });

  return (
    <div>
      <div className="flex items-center mb-6">
        <button onClick={onBack} className="text-xs font-bold text-tealBrand-600 hover:text-tealBrand-700 mr-4">
          ← Back
        </button>
        <h2 className="text-lg font-extrabold text-slate-900">{title} Calculator</h2>
      </div>

      <InputGroup label={`Current YTD ${title}`} value={ytdIncome} onChangeText={setYtdIncome} prefix="$" placeholder="12,500.00" />
      <InputGroup label="YTD Pay Period Ending Date" value={payPeriodDate} onChangeText={setPayPeriodDate} placeholder="YYYY-MM-DD" />
      <InputGroup label={`Prior Year (12-Mo) ${title}`} value={priorYearIncome} onChangeText={setPriorYearIncome} prefix="$" placeholder="22,000.00" />
      <InputGroup label={`2nd Prior Year ${title} (Optional)`} value={secondPriorYearIncome} onChangeText={setSecondPriorYearIncome} prefix="$" placeholder="20,000.00" />

      <HistoricalResultCard result={result} />
    </div>
  );
};