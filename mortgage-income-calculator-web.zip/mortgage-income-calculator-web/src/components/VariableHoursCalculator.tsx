import React, { useState } from 'react';
import { calculateHistoricalIncome } from '../calculations/historicalIncome';
import { InputGroup } from './InputGroup';
import { HistoricalResultCard } from './HistoricalResultCard';

export const VariableHoursCalculator: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const [ytdIncome, setYtdIncome] = useState('');
  const [payPeriodDate, setPayPeriodDate] = useState('2026-06-30');
  const [priorYearIncome, setPriorYearIncome] = useState('');
  const [secondPriorYearIncome, setSecondPriorYearIncome] = useState('');
  const [startDate, setStartDate] = useState('');

  const result = calculateHistoricalIncome({
    incomeTypeLabel: 'Variable Hours Income',
    ytdIncome,
    payPeriodDate,
    priorYearIncome,
    secondPriorYearIncome,
    startDate,
  });

  return (
    <div>
      <div className="flex items-center mb-6">
        <button onClick={onBack} className="text-xs font-bold text-tealBrand-600 hover:text-tealBrand-700 mr-4">
          ← Back
        </button>
        <h2 className="text-lg font-extrabold text-slate-900">Variable Hours Calculator</h2>
      </div>

      <InputGroup label="Current YTD Gross Income" value={ytdIncome} onChangeText={setYtdIncome} prefix="$" placeholder="24,500.00" />
      <InputGroup label="YTD Pay Period Ending Date" value={payPeriodDate} onChangeText={setPayPeriodDate} placeholder="YYYY-MM-DD" helpText="Format: YYYY-MM-DD" />
      <InputGroup label="Prior Year (W-2) Gross Income" value={priorYearIncome} onChangeText={setPriorYearIncome} prefix="$" placeholder="52,000.00" />
      <InputGroup label="2nd Prior Year Gross Income (Optional)" value={secondPriorYearIncome} onChangeText={setSecondPriorYearIncome} prefix="$" placeholder="49,500.00" />
      <InputGroup label="Employment Start Date (Optional)" value={startDate} onChangeText={setStartDate} placeholder="YYYY-MM-DD" helpText="Only if hired within current calendar year" />

      <HistoricalResultCard result={result} />
    </div>
  );
};