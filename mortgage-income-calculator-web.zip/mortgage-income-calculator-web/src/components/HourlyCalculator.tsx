import React, { useState } from 'react';
import { calculateHourlyIncome } from '../calculations/hourly';
import { InputGroup } from './InputGroup';
import { ResultCard } from './ResultCard';

export const HourlyCalculator: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const [hourlyRate, setHourlyRate] = useState('');
  const [hoursPerWeek, setHoursPerWeek] = useState('40');

  const result = calculateHourlyIncome({ hourlyRate, hoursPerWeek });

  return (
    <div>
      <div className="flex items-center mb-6">
        <button onClick={onBack} className="text-xs font-bold text-tealBrand-600 hover:text-tealBrand-700 mr-4">
          ← Back
        </button>
        <h2 className="text-lg font-extrabold text-slate-900">Hourly Base Calculator</h2>
      </div>

      <InputGroup
        label="Hourly Pay Rate"
        value={hourlyRate}
        onChangeText={setHourlyRate}
        prefix="$"
        placeholder="35.00"
      />

      <InputGroup
        label="Average Hours Per Week"
        value={hoursPerWeek}
        onChangeText={setHoursPerWeek}
        suffix="hrs/wk"
        placeholder="40"
        helpText="Standard full-time employment is 40 hours per week."
      />

      <ResultCard result={result} />
    </div>
  );
};