import React from 'react';
import { CalculationResult } from '../types/income';
import { formatCurrency, formatPercentage } from '../utils/formatters';

export const ResultCard: React.FC<{ result: CalculationResult }> = ({ result }) => {
  const { trend } = result;

  return (
    <div className="mt-6 bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
      <h2 className="text-[10px] font-extrabold text-slate-400 tracking-wider uppercase">
        ESTIMATED MONTHLY QUALIFYING INCOME
      </h2>
      <div className="text-3xl sm:text-4xl font-extrabold text-tealBrand-700 my-1">
        {formatCurrency(result.monthlyQualifyingIncome)}
      </div>

      <div className="inline-block bg-tealBrand-100 text-tealBrand-800 text-xs font-bold px-2.5 py-1 rounded-md mb-4">
        Annualized: {formatCurrency(result.annualizedIncome)}
      </div>

      <hr className="border-slate-200 my-4" />

      <div className="mb-4">
        <h3 className="text-[10px] font-extrabold text-slate-400 tracking-wider uppercase mb-1">
          CALCULATION METHODOLOGY
        </h3>
        <p className="text-xs font-semibold text-slate-800">{result.methodology}</p>
      </div>

      {trend && (
        <div className="mb-4">
          <h3 className="text-[10px] font-extrabold text-slate-400 tracking-wider uppercase mb-1">
            INCOME TREND ANALYSIS
          </h3>
          <p className={`text-xs font-bold ${trend.isDeclining ? 'text-red-600' : 'text-emerald-600'}`}>
            Trend: {trend.direction} ({formatPercentage(trend.percentageChange)})
          </p>
          {trend.isDeclining && trend.warningMessage && (
            <div className="mt-2 bg-red-50 border border-red-200 rounded-lg p-3 text-xs font-medium text-red-700">
              ⚠️ {trend.warningMessage}
            </div>
          )}
        </div>
      )}

      <div className="pt-3 border-t border-slate-100">
        <p className="text-[10px] leading-relaxed text-slate-400">
          This calculator is an educational and income-analysis tool. Results do not constitute underwriting approval. Actual qualifying income may vary based on loan program, investor, agency, lender, documentation, and underwriting requirements.
        </p>
      </div>
    </div>
  );
};