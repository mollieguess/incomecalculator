import React, { useState } from 'react';
import { calculateHistoricalIncome } from '../calculations/historicalIncome';
import { InputGroup } from './InputGroup';
import { HistoricalResultCard } from './HistoricalResultCard';

export const YtdAnalysisCalculator: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const [ytdIncome, setYtdIncome] = useState('');
  const [payPeriodDate, setPayPeriodDate] = useState('2026-06-30');
  const [priorYearIncome, setPriorYearIncome] = useState('');
  const [secondPriorYearIncome, setSecondPriorYearIncome] = useState('');

  const result = calculateHistoricalIncome({
    incomeTypeLabel: 'Comprehensive YTD Total',
    ytdIncome,
    payPeriodDate,
    priorYearIncome,
    secondPriorYearIncome,
  });

  return (
    <div>
      <div className="flex items-center mb-6">
        <button onClick={onBack} className="text-xs font-bold text-tealBrand-600 hover:text-tealBrand-700 mr-4">
          ← Back
        </button>
        <h2 className="text-lg font-extrabold text-slate-900">YTD Income Analysis</h2>
      </div>

      <div className="bg-slate-100 p-3 rounded-lg text-xs text-slate-600 mb-4 leading-relaxed">
        Analyze total borrower gross earnings across multi-year pay stubs and W-2 statements to check overall stability.
      </div>

      <InputGroup label="Total YTD Gross Earnings" value={ytdIncome} onChangeText={setYtdIncome} prefix="$" placeholder="48,000.00" />
      <InputGroup label="Pay Period End Date" value={payPeriodDate} onChangeText={setPayPeriodDate} placeholder="YYYY-MM-DD" />
      <InputGroup label="Prior Year Total Earnings (W-2)" value={priorYearIncome} onChangeText={setPriorYearIncome} prefix="$" placeholder="92,000.00" />
      <InputGroup label="2nd Prior Year Earnings (Optional)" value={secondPriorYearIncome} onChangeText={setSecondPriorYearIncome} prefix="$" placeholder="88,000.00" />

      <HistoricalResultCard result={result} />
    </div>
  );
};