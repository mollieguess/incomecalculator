import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="bg-white border-b border-slate-200 py-6 px-4 text-center shadow-sm">
      <div className="max-w-4xl mx-auto">
        <span className="text-[10px] font-extrabold text-tealBrand-600 tracking-widest uppercase block mb-1">
          MLO QUALIFIER PRO
        </span>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          MORTGAGE INCOME CALCULATOR
        </h1>
        <p className="text-sm font-medium text-slate-500 mt-1">
          Calculate. Analyze. Qualify.
        </p>
      </div>
    </header>
  );
};