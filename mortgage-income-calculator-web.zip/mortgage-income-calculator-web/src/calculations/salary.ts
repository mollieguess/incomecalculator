import { SalaryInput, CalculationResult } from '../types/income';
import { parseCleanNumber, formatCurrency } from '../utils/formatters';

export const calculateSalaryIncome = (input: SalaryInput): CalculationResult => {
  const numericAmount = parseCleanNumber(input.amount);
  if (numericAmount <= 0) {
    return {
      monthlyQualifyingIncome: 0,
      annualizedIncome: 0,
      methodology: 'Enter a valid base salary to calculate qualifying income.',
    };
  }

  let monthly = 0;
  let annual = 0;
  let methodology = '';

  if (input.frequency === 'ANNUAL') {
    annual = numericAmount;
    monthly = numericAmount / 12;
    methodology = `${formatCurrency(annual)} annual salary ÷ 12 months`;
  } else {
    monthly = numericAmount;
    annual = numericAmount * 12;
    methodology = `${formatCurrency(monthly)} monthly salary × 12 months = ${formatCurrency(annual)}/yr`;
  }

  return { monthlyQualifyingIncome: monthly, annualizedIncome: annual, methodology };
};