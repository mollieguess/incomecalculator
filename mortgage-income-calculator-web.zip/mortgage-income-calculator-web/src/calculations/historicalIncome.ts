import { HistoricalIncomeInput, CalculationResult } from '../types/income';
import { parseCleanNumber, formatCurrency } from '../utils/formatters';
import { calculateYtdMonths } from '../utils/dates';
import { calculateIncomeTrend } from '../utils/trends';

export const calculateHistoricalIncome = (input: HistoricalIncomeInput): CalculationResult => {
  const ytdGross = parseCleanNumber(input.ytdIncome);
  const priorGross = parseCleanNumber(input.priorYearIncome);
  const secondPriorGross = parseCleanNumber(input.secondPriorYearIncome || '0');

  const { ytdMonths, error } = calculateYtdMonths(input.payPeriodDate, input.startDate);

  if (error || ytdGross <= 0 || ytdMonths <= 0) {
    return {
      monthlyQualifyingIncome: 0,
      annualizedIncome: 0,
      methodology: error || 'Enter valid YTD gross income and pay period end date.',
    };
  }

  const currentYtdAverage = ytdGross / ytdMonths;
  const priorYearAverage = priorGross > 0 ? priorGross / 12 : 0;
  const secondPriorYearAverage = secondPriorGross > 0 ? secondPriorGross / 12 : 0;

  let totalMonths = ytdMonths;
  let totalIncome = ytdGross;

  if (priorGross > 0) {
    totalMonths += 12;
    totalIncome += priorGross;
  }
  if (secondPriorGross > 0) {
    totalMonths += 12;
    totalIncome += secondPriorGross;
  }

  const historicalAverage = totalIncome / totalMonths;
  const trend = calculateIncomeTrend(currentYtdAverage, priorYearAverage > 0 ? priorYearAverage : historicalAverage);

  let qualifyingMonthly = historicalAverage;
  let selectionReason = 'historical average (stable/increasing trend)';

  if (trend.isDeclining) {
    qualifyingMonthly = Math.min(currentYtdAverage, historicalAverage);
    selectionReason = 'conservative YTD average (due to declining income trend)';
  }

  return {
    monthlyQualifyingIncome: qualifyingMonthly,
    annualizedIncome: qualifyingMonthly * 12,
    currentYtdAverage,
    priorYearAverage,
    historicalAverage,
    trend,
    methodology: `${input.incomeTypeLabel} calculated over ${totalMonths.toFixed(1)} total months. Used ${selectionReason}. (YTD: ${formatCurrency(currentYtdAverage)}/mo | Prior Yr: ${formatCurrency(priorYearAverage)}/mo)`,
  };
};