import { HourlyInput, CalculationResult } from '../types/income';
import { parseCleanNumber, formatCurrency } from '../utils/formatters';

export const calculateHourlyIncome = (input: HourlyInput): CalculationResult => {
  const rate = parseCleanNumber(input.hourlyRate);
  const hours = parseCleanNumber(input.hoursPerWeek);

  if (rate <= 0 || hours <= 0) {
    return {
      monthlyQualifyingIncome: 0,
      annualizedIncome: 0,
      methodology: 'Enter hourly rate and weekly hours to calculate income.',
    };
  }

  const annual = rate * hours * 52;
  const monthly = annual / 12;

  return {
    monthlyQualifyingIncome: monthly,
    annualizedIncome: annual,
    methodology: `${formatCurrency(rate)}/hr × ${hours.toFixed(1)} hrs/wk × 52 wks ÷ 12 mos`,
  };
};