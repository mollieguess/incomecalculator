import { TrendAnalysis, TrendDirection } from '../types/income';

export const calculateIncomeTrend = (
  currentYtdAvg: number,
  priorYearAvg: number
): TrendAnalysis => {
  if (priorYearAvg <= 0 || currentYtdAvg <= 0) {
    return { direction: 'STABLE', percentageChange: 0, isDeclining: false };
  }

  const percentageChange = ((currentYtdAvg - priorYearAvg) / priorYearAvg) * 100;
  let direction: TrendDirection = 'STABLE';
  
  if (percentageChange > 2.0) direction = 'INCREASING';
  else if (percentageChange < -2.0) direction = 'DECLINING';

  const isDeclining = percentageChange < -5.0;

  return {
    direction,
    percentageChange: parseFloat(percentageChange.toFixed(2)),
    isDeclining,
    warningMessage: isDeclining
      ? 'Declining income detected. Additional underwriting analysis may be required. Qualifying income defaulted to lower current YTD average per agency guidelines.'
      : undefined,
  };
};