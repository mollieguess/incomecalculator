export const calculateYtdMonths = (
  payPeriodDateStr: string,
  startDateStr?: string
): { ytdMonths: number; error?: string } => {
  if (!payPeriodDateStr) return { ytdMonths: 0, error: 'Pay period date is required.' };

  const payPeriodDate = new Date(payPeriodDateStr);
  if (isNaN(payPeriodDate.getTime())) return { ytdMonths: 0, error: 'Invalid pay period date.' };

  const currentYear = payPeriodDate.getFullYear();
  let yearStart = new Date(currentYear, 0, 1);

  if (startDateStr) {
    const startDate = new Date(startDateStr);
    if (!isNaN(startDate.getTime()) && startDate > yearStart && startDate <= payPeriodDate) {
      yearStart = startDate;
    }
  }

  const diffTime = payPeriodDate.getTime() - yearStart.getTime();
  const diffDays = Math.max(1, Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1);
  const ytdMonths = Math.min(12, Math.max(0.1, diffDays / 30.4375));

  return { ytdMonths: parseFloat(ytdMonths.toFixed(2)) };
};