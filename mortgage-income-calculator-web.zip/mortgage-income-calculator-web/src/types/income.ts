export type IncomeType = 
  | 'SALARY'
  | 'HOURLY'
  | 'VARIABLE_HOURS'
  | 'OVERTIME'
  | 'BONUS'
  | 'COMMISSION'
  | 'YTD_ANALYSIS';

export type SalaryFrequency = 'ANNUAL' | 'MONTHLY';
export type TrendDirection = 'INCREASING' | 'STABLE' | 'DECLINING';

export interface TrendAnalysis {
  direction: TrendDirection;
  percentageChange: number;
  isDeclining: boolean;
  warningMessage?: string;
}

export interface CalculationResult {
  monthlyQualifyingIncome: number;
  annualizedIncome: number;
  methodology: string;
  currentYtdAverage?: number;
  priorYearAverage?: number;
  historicalAverage?: number;
  trend?: TrendAnalysis;
}

export interface SalaryInput {
  frequency: SalaryFrequency;
  amount: string;
}

export interface HourlyInput {
  hourlyRate: string;
  hoursPerWeek: string;
}

export interface HistoricalIncomeInput {
  incomeTypeLabel: string;
  ytdIncome: string;
  payPeriodDate: string;
  priorYearIncome: string;
  secondPriorYearIncome?: string;
  startDate?: string;
}